#!/usr/bin/env python
# Authors:
#   haoyan <haoyan2@cisco.com>

import datetime
import traceback
import StringIO
import distutils.spawn
import os.path
import subprocess
import string
import re
import glob
import json

if __name__ != '__main__':
    import collectd


class Base_Subsystem(object):

    def __init__(self):
        self.plugin = "ceph"

    def config_callback(self, conf):
        # InternalConfig
        self.config = conf

    def execute_command(self, command_string, json_decode=False):
        output = None
        try:
            output = subprocess.check_output(command_string, shell=True)
            if output is None:
                self.logger(
                    'err',
                    "execute command [ %s ] has no result" %
                    command_string)
            elif json_decode:
                output = json.loads(output)
        except Exception as exc:
            self.logger(
                'err', "execute command [ %s ] error:: %s :: %s" %
                (command_string, exc, traceback.format_exc()))
            output = None
        finally:
            return output

    def dispatch_value(
            self, plugin, plugin_instance, type, type_instance, value):
        self.logger(
            'verb',
            "Dispatching value %s.%s.%s.%s.%s" %
            (plugin,
             plugin_instance,
             type,
             type_instance,
             value))
        if self.config.cli:
            return
        val = collectd.Values()
        val.plugin = plugin
        val.plugin_instance = plugin_instance
        val.type = type
        val.values = [value]
        val.interval = self.config.interval
        val.dispatch()
        self.logger(
            'verb',
            "sent metric %s.%s.%s.%s.%s" %
            (plugin,
             plugin_instance,
             type,
             type_instance,
             value))

    def dispatch(self, stats):
        if not stats:
            self.logger('err', '%s: failed to retrieve stats ' % self.prefix)
            return
        try:
            for plugin in stats.keys():
                for plugin_instance in stats[plugin].keys():
                    for type in stats[plugin][plugin_instance].keys():
                        type_value = stats[plugin][plugin_instance][type]
                        if not isinstance(type_value, dict):
                            self.dispatch_value(
                                plugin,
                                plugin_instance,
                                type,
                                None,
                                type_value)
                        else:
                            for type_instance in stats[plugin][
                                    plugin_instance][type].keys():
                                type_value = stats[plugin][
                                    plugin_instance][type][type_instance]
                                self.dispatch_value(
                                    plugin,
                                    plugin_instance,
                                    type,
                                    type_instance,
                                    type_value)

        except Exception as e:
            self.logger(
                'err', "failed to dispatch stats %s :: %s" %
                (e, traceback.format_exc()))

    def read_callback(self):
        self.logger('err', 'not implemented')

    def capabilityTest(self):
        return False

    def logger(self, t, msg):
        if self.config.cli:
            print t + " " + msg
            return
        if t == 'err':
            collectd.error('%s: %s' % (self.plugin, msg))
        if t == 'warn':
            collectd.warning('%s: %s' % (self.plugin, msg))
        elif t == 'verb' and self.config.verbose:
            collectd.info('%s: %s' % (self.plugin, msg))

    def check_command_exist(self, command):
        return distutils.spawn.find_executable(command) is not None

    def check_file_exist(self, files):
        """
            files: array,just check the first one
        """
        if len(files) > 0:
            return os.path.exists(files[0])
        return False


class InternalConfig(object):
    pass

support_subsystem_list = [
    "KvmCephVolume",
    "CephOsdPlugin",
    "CephOsdNodePlugin",
    "CephClusterPlugin"]


class CephCollectdPlugin(object):

    def __init__(self):
        self.configure = InternalConfig()

    def add_config(self, key, value):
        setattr(self.configure, key, value)

    def config(self, conf):
        """
        Takes a collectd config object and deal with import

        """
        for node in conf.children:
            if node.key == "verbose":
                if node.values[0] in ['True', 'true']:
                    self.add_config(node.key, True)
            elif node.key == 'interval':
                self.add_config(node.key, float(node.values[0]))
            elif node.key == "ceph_admin_mon_socket_path":
                self.add_config("mon_socket_path", node.values[0])
            elif node.key == "ceph_admin_osd_socket_path":
                self.add_config("osd_socket_path", node.values[0])

    def read_callback(self):
        out = globals()
        for subsystem in support_subsystem_list:
            claz = out[subsystem]
            obj = claz()
            obj.config_callback(self.configure)
            if obj.capabilityTest():
                obj.read_callback()


class KvmCephVolume(Base_Subsystem):

    def __init__(self):
        Base_Subsystem.__init__(self)
        self.plugin = "kvm-ceph"

    def capabilityTest(self):
        return self.check_command_exist("virsh")

    def read_callback(self):
        output = self.execute_command(
            """ virsh list | sed '1d;2d' | awk '{if($3 == "running")print $2}' """)
        if output is not None:
            instance_ids = output.split()
            for instance_id in instance_ids:
                output = self.execute_command(
                    """virsh qemu-monitor-command %s --pretty '{"execute":"query-blockstats"}'""" %
                    instance_id, True)
                if output is None:
                    continue
                plugin_instance = "volume-%s" % instance_id
                data = {self.plugin: {
                    plugin_instance: {
                        "read_kb_sec": 0,
                        "read_reqs_sec": 0,
                        "write_reqs_sec": 0,
                        "write_kb_sec": 0
                    }}}
                data[self.plugin][plugin_instance]["read_kb_sec"] = output[
                    "return"][0]["stats"]["rd_bytes"] / 1024
                data[self.plugin][plugin_instance]["read_reqs_sec"] = output[
                    "return"][0]["stats"]["rd_operations"]
                data[self.plugin][plugin_instance]["write_reqs_sec"] = output[
                    "return"][0]["stats"]["wr_operations"]
                data[self.plugin][plugin_instance]["write_kb_sec"] = output[
                    "return"][0]["stats"]["wr_bytes"] / 1024
                self.dispatch(data)


class CephOsdPlugin(Base_Subsystem):

    def __init__(self):
        Base_Subsystem.__init__(self)
        self.plugin = "ceph-cluster"

    def capabilityTest(self):
        self.admin_socket = glob.glob(self.config.osd_socket_path)
        return self.check_file_exist(self.admin_socket)

    def read_callback(self):

        for admin_soc in self.admin_socket:
            perfs = self.execute_command(
                "ceph --admin-daemon %s perf dump -f json" %
                admin_soc,
                json_decode=True)
            if perfs is None:
                return
            plugin_instance = "osd-%s" % admin_soc.split('.')[1]
            data = {self.plugin: {plugin_instance: {}}}
            data[self.plugin][plugin_instance][
                "osd_opR"] = perfs["osd"]["op_r"]
            data[self.plugin][plugin_instance][
                "osd_opW"] = perfs["osd"]["op_w"]
            data[self.plugin][plugin_instance][
                "osd_op_in_kb"] = perfs["osd"]["op_in_bytes"] / 1024
            data[self.plugin][plugin_instance][
                "osd_op_out_kb"] = perfs["osd"]["op_out_bytes"] / 1024
            data[self.plugin][plugin_instance][
                "osd_op_rw_in_kb"] = perfs["osd"]["op_rw_in_bytes"] / 1024
            data[self.plugin][plugin_instance]["osd_op_rw_out_kb"] = perfs[
                "osd"]["op_rw_out_bytes"] / 1024
            data[self.plugin][plugin_instance]["osd_op_r_latency"] = perfs["osd"][
                "op_r_latency"]["sum"] / perfs["osd"]["op_r_latency"]["avgcount"]
            data[self.plugin][plugin_instance]["osd_op_w_latency"] = perfs["osd"][
                "op_w_latency"]["sum"] / perfs["osd"]["op_w_latency"]["avgcount"]
            data[self.plugin][plugin_instance][
                "osd_subop_in_kb"] = perfs["osd"]["subop_in_bytes"] / 1024
            data[self.plugin][plugin_instance]["osd_subop_latency"] = perfs["osd"][
                "subop_latency"]["sum"] / perfs["osd"]["subop_latency"]["avgcount"]
            data[self.plugin][plugin_instance]["osd_subop_w_in_kb"] = perfs[
                "osd"]["subop_w_in_bytes"] / 1024
            data[self.plugin][plugin_instance]["osd_subop_w_latency"] = perfs["osd"][
                "subop_w_latency"]["sum"] / perfs["osd"]["subop_w_latency"]["avgcount"]
            self.dispatch(data)


class CephOsdNodePlugin(Base_Subsystem):

    def __init__(self):
        Base_Subsystem.__init__(self)
        self.status_map = {
            'HEALTH_OK': 0,
            'HEALTH_WARN': 1,
            'HEALTH_ERR': 2,
            'HEALTH_UNKNOW': 3}
        self.plugin = "ceph-cluster"

    def capabilityTest(self):
        self.admin_socket = glob.glob(self.config.osd_socket_path)
        return self.check_file_exist(self.admin_socket)

    def read_callback(self):
        data = {self.plugin: {
            "pg": {}
        }}
        output = self.execute_command("ceph -s -f json", True)
        if output is not None:
            status = self.status_map.get(output["health"]["overall_status"])
            if status is None:
                status = self.status_map['HEALTH_UNKNOW']
            num_pg_degraded = num_pg_down = num_pg_incomplete = num_pg_stale = 0
            for pg_detail in output["pgmap"]["pgs_by_state"]:
                name = pg_detail.get("state_name")
                value = pg_detail.get("count") or 0
                if name.find("degraded") >= 0:
                    num_pg_degraded = num_pg_degraded + value
                if name.find("down") >= 0:
                    num_pg_down = num_pg_down + value
                if name.find("incomplete") >= 0:
                    num_pg_incomplete = num_pg_incomplete + value
                if name.find("stale") >= 0:
                    num_pg_stale = num_pg_stale + value
                data[self.plugin]["pg"]["overall_status"] = status
                data[self.plugin]["pg"]["num_pg_degraded"] = num_pg_degraded
                data[self.plugin]["pg"][
                    "num_pg_incomplete"] = num_pg_incomplete
                data[self.plugin]["pg"]["num_pg_stale"] = num_pg_stale
                data[self.plugin]["pg"]["num_pg_down"] = num_pg_down
        output = self.execute_command("iostat -Ndxk", False)
        ios = StringIO.StringIO(output)
        lines = ios.readlines()
        os_release_pattern = re.compile("^(Linux|$)")
        table_header_pattern = re.compile("^Device")
        table_header_dict = {}
        for line in lines:
            if os_release_pattern.match(line):
                pass
            elif table_header_pattern.match(line):
                table_header_array = line.split()
                table_header_dict = dict(
                    zip(table_header_array, range(len(table_header_array))))
            else:
                values = line.split()
                Device = values[table_header_dict["Device:"]]
                plugin_instance = "device-%s" % Device
                read_reqs_sec = values[table_header_dict["r/s"]]
                write_reqs_sec = values[table_header_dict["w/s"]]
                read_kb_sec = values[table_header_dict["rkB/s"]]
                write_kb_sec = values[table_header_dict["wkB/s"]]
                queue_lenth = values[table_header_dict["avgqu-sz"]]
                response_time = values[table_header_dict["await"]]
                data[self.plugin][plugin_instance] = {}
                data[self.plugin][plugin_instance][
                    "read_reqs_sec"] = read_reqs_sec
                data[self.plugin][plugin_instance][
                    "write_reqs_sec"] = write_reqs_sec
                data[self.plugin][plugin_instance]["read_kb_sec"] = read_kb_sec
                data[self.plugin][plugin_instance][
                    "write_kb_sec"] = write_kb_sec
                data[self.plugin][plugin_instance]["queue_lenth"] = queue_lenth
                data[self.plugin][plugin_instance][
                    "response_time"] = response_time
        self.dispatch(data)


class CephClusterPlugin(Base_Subsystem):

    def __init__(self):
        Base_Subsystem.__init__(self)
        self.plugin = "ceph-cluster"

    def capabilityTest(self):
        self.admin_socket = glob.glob(self.config.mon_socket_path)
        return self.check_file_exist(self.admin_socket)

    def read_callback(self):
        data = {self.plugin: {
            "mon": {
            }}}
        for admin_soc in self.admin_socket:
            out = self.execute_command(
                "ceph --admin-daemon %s perf dump -f json" %
                admin_soc,
                json_decode=True)
            data[self.plugin]["mon"]["num_mon"] = out["cluster"]["num_mon"]
            data[self.plugin]["mon"]["num_mon_quorum"] = out[
                "cluster"]["num_mon_quorum"]
            data[self.plugin]["mon"]["num_osd"] = out["cluster"]["num_osd"]
            data[self.plugin]["mon"]["num_osd_up"] = out[
                "cluster"]["num_osd_up"]
            data[self.plugin]["mon"]["num_osd_in"] = out[
                "cluster"]["num_osd_in"]

            data[
                self.plugin]["mon"]["osd_gb"] = self.field_compat(
                out["cluster"],
                "osd_kb",
                "osd_bytes")
            data[
                self.plugin]["mon"]["osd_gb_used"] = self.field_compat(
                out["cluster"],
                "osd_kb_used",
                "osd_bytes_used")
            data[
                self.plugin]["mon"]["osd_gb_avail"] = self.field_compat(
                out["cluster"],
                "osd_kb_avail",
                "osd_bytes_avail")

            data[self.plugin]["mon"]["num_pool"] = out["cluster"]["num_pool"]
            data[self.plugin]["mon"]["num_pg"] = out["cluster"]["num_pg"]
            data[self.plugin]["mon"]["num_pg_active_clean"] = out[
                "cluster"]["num_pg_active_clean"]
            data[self.plugin]["mon"]["num_pg_active"] = out[
                "cluster"]["num_pg_active"]
            data[self.plugin]["mon"]["num_pg_peering"] = out[
                "cluster"]["num_pg_peering"]
            data[self.plugin]["mon"]["num_object"] = out[
                "cluster"]["num_object"]
            data[self.plugin]["mon"]["num_object_degraded"] = out[
                "cluster"]["num_object_degraded"]
            data[self.plugin]["mon"]["num_object_unfound"] = out[
                "cluster"]["num_object_unfound"]
            data[self.plugin]["mon"]["num_gb"] = out[
                "cluster"]["num_bytes"] / (1024 * 1024 * 1024)
            data[self.plugin]["mon"]["num_mds_up"] = out[
                "cluster"]["num_mds_up"]
            data[self.plugin]["mon"]["num_mds_in"] = out[
                "cluster"]["num_mds_in"]
            data[self.plugin]["mon"]["num_mds_failed"] = out[
                "cluster"]["num_mds_failed"]
            self.dispatch(data)

    def field_compat(self, dict, old_kb, new_bytes):
        if old_kb in dict:
            return self.kb2gb(dict[old_kb])
        else:
            return self.byte2gb(dict[new_bytes])

    def byte2gb(self, bytes):
        return bytes / (1024 * 1024 * 1024)

    def kb2gb(self, kb):
        return kb / (1024 * 1024)


ceph_plugin = CephCollectdPlugin()
# defalut config value
ceph_plugin.add_config('verbose', False)
ceph_plugin.add_config('interval', 60)
ceph_plugin.add_config('cli', False)
ceph_plugin.add_config('mon_socket_path', "/var/run/ceph/ceph-mon.*.asok")
ceph_plugin.add_config('osd_socket_path', "/var/run/ceph/ceph-osd.*.asok")


if __name__ == '__main__':
    ceph_plugin.add_config('cli', True)
    ceph_plugin.read_callback()
else:
    collectd.register_config(ceph_plugin.config)
    collectd.register_read(ceph_plugin.read_callback)
